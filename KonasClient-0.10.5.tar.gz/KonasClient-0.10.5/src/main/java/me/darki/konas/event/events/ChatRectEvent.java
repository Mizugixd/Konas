package me.darki.konas.event.events;

public class ChatRectEvent extends CancellableEvent {
}
