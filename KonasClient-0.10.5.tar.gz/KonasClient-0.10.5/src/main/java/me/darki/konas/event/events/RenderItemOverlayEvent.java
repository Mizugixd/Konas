package me.darki.konas.event.events;

public class RenderItemOverlayEvent extends CancellableEvent {
}
