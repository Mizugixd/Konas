package me.darki.konas.event.events;

public class WebEvent extends CancellableEvent { }
