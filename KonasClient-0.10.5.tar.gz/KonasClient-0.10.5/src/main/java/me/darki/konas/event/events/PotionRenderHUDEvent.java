package me.darki.konas.event.events;

public class PotionRenderHUDEvent extends CancellableEvent {}
