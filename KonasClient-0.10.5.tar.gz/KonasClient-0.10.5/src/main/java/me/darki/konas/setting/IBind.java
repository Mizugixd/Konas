package me.darki.konas.setting;

public interface IBind {
    int getKeyCode();

    void setKeyCode(int keyCode);
}
