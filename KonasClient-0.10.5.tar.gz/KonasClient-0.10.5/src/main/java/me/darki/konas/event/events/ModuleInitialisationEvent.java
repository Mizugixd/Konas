package me.darki.konas.event.events;

public class ModuleInitialisationEvent {

    public static class Pre extends ModuleInitialisationEvent {

    }

    public static class Post extends ModuleInitialisationEvent {

    }


}
