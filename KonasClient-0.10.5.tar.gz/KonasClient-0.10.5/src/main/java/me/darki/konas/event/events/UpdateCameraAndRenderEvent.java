package me.darki.konas.event.events;

public class UpdateCameraAndRenderEvent {
    public static class Pre extends UpdateCameraAndRenderEvent {
        public Pre() {
            super();
        }
    }

    public static class Post extends UpdateCameraAndRenderEvent {
        public Post() {
            super();
        }
    }
}
