package me.darki.konas.setting;

public interface IRunnable<T> {

    void run(T arg);

}
