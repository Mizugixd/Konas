package me.darki.konas.event.events;

// This is the ultimate parent event, which is called at every main game loop head
public class RootEvent {
}
