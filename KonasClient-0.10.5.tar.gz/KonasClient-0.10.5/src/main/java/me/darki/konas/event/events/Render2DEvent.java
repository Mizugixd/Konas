package me.darki.konas.event.events;


public class Render2DEvent {
}
